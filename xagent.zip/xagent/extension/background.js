console.log("Selenium Test Extension Loaded");
