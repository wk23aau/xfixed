# core_instructions.md
