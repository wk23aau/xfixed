# Output Format

Respond ONLY in this format:
```
STATUS: [READY|PROCESSING|COMPLETE|ERROR]
TASK_ID: [task identifier]
RESULT: [your response]
```
